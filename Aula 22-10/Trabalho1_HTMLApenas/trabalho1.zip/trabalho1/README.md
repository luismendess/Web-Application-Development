# trabalho1
Este é um currículo fictício para a matéria de Desenvolvimento de Aplicações Web da Faculdade, usando apenas HTML
