# trabalho1parte4
 Esta é a continuação do trabalho 1 parte 3, agora introduzindo CSS ao código HTML criado
