# trabalho1parte5
 Esta é a continuação do trabalho 1 parte 3 e parte 4, agora introduzindo responsividade ao site criado
