<?php
// recuperando dados do formulario
$nome = $_POST['nome'];
$telefone = $_POST['telefone'];

// variáveis ref. A conexão ao bd
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alunosInvDB";

// criando a string de Conexao com o BD
$strcon = new mysqli($servername, $username, $password, $dbname);

// Verifica se houve erro na conexão
if ($strcon->connect_error) {
    die("Erro ao conectar ao banco de dados: " . $strcon->connect_error);
}

// criação da Instrução SQL DML para inserção dos dados usando prepared statements
$sql = $strcon->prepare("INSERT INTO aluno (nome, telefone) VALUES (?, ?)");

// Bind dos parâmetros para evitar SQL Injection
$sql->bind_param("ss", $nome, $telefone);

// execução da instrução SQL DML de Insert 
if ($sql->execute()) {
    echo "Aluno cadastrado com sucesso!";
} else {
    echo "Erro ao tentar cadastrar no BD: " . $sql->error;
}

// fechamento da conexão com o bd.
$sql->close();
$strcon->close();
